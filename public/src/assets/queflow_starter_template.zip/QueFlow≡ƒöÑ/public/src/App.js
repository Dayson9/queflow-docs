import { App } from "queflow"
import Main from './nuggets/Main.js';


const MyApp = new App("#app", {
  template: () => `
    <Main { title: "QueFlow", text: "Caution: do not look into laser with remaining eye." } />
    `
})

MyApp.render()