import { Nugget } from 'queflow'

const Main = new Nugget('Main', {
  template: () => {
    return `
      <h1>{{ title }}</h1>
      <p color="orange">{{ text }}</p>
    `
  },

  stylesheet: {
    '*': `
      margin-left: 30px;
    `
  }
})

export default Main